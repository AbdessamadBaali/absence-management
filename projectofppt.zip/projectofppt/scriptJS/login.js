$(document).ready(function(){
    msgerror = false;

    $('#btnLogin').click(function() {
        // alert($("#feed_back").text());
        if ( $("#feed_back").text().length > 0 ){
            // msgerror = true;
            $('#alert').toggleClass("visually-hidden");

           
        }
    })

    $("#form-login").submit( (e) => {
        if (msgerror === true){
            e.preventDefault();
        } 
    })
  
  });
    
    